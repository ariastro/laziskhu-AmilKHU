package org.laziskhu.amilkhu.utils

import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import timber.log.Timber

fun View.toVisible() {
    visibility = View.VISIBLE
}

fun View.toGone() {
    visibility = View.GONE
}

fun logDebug(message: String) {
    Timber.d(message)
}

fun logError(message: String, throwable: Throwable? = null) {
    Timber.e(throwable, message)
}

fun EditText.afterTextChanged(afterTextChanged: (String) -> Unit) {
    this.addTextChangedListener(object : TextWatcher {
        override fun afterTextChanged(editable: Editable?) {
            afterTextChanged.invoke(editable.toString())
        }

        override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

        override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
    })
}