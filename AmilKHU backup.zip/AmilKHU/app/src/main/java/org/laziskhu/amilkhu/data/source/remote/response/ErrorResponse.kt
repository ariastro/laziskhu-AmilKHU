package org.laziskhu.amilkhu.data.source.remote.response

data class ErrorResponse(
  val status: Boolean,
  val message: String?
)
