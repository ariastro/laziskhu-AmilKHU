package org.laziskhu.amilkhu.data.source

import com.skydoves.sandwich.map
import com.skydoves.sandwich.onError
import com.skydoves.sandwich.onException
import com.skydoves.sandwich.suspendOnSuccess
import org.laziskhu.amilkhu.vo.Resource
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onStart
import org.laziskhu.amilkhu.data.source.remote.RemoteDataSource
import org.laziskhu.amilkhu.utils.ErrorResponseMapper
import javax.inject.Inject

class AmilkhuRepository @Inject constructor(
    private val remoteDataSource: RemoteDataSource,
    private val ioDispatcher: CoroutineDispatcher
) : AmilkhuDataSource {

    override fun login(username: String, password: String) = flow {
        val response = remoteDataSource.login(username, password)
        response.suspendOnSuccess {
            emit(Resource.success(data))
        }.onError {
            map(ErrorResponseMapper) {
                Resource.error(message, null)
            }
        }.onException {
            Resource.error(message, null)
        }
    }.onStart { Resource.loading(null) }.flowOn(ioDispatcher)

}
