package org.laziskhu.amilkhu.ui.auth.login

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import org.laziskhu.amilkhu.databinding.ActivityLoginBinding
import org.laziskhu.amilkhu.utils.logDebug
import org.laziskhu.amilkhu.vo.Status

class LoginActivity : AppCompatActivity() {

    private var _binding: ActivityLoginBinding? = null
    private val binding get() = _binding!!
    private val viewModel: LoginViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            viewModel.login(binding.username.text.toString(), binding.password.text.toString()).observe(this) {
                when (it.status) {
                    Status.SUCCESS -> {
                        logDebug("onSuccess")
                    }
                    Status.LOADING -> {
                        logDebug("onLoading")
                    }
                    Status.ERROR -> {
                        logDebug("onError")
                    }
                }
            }
        }

//        loginViewModel.loginFormState.observe(this, Observer {
//            val loginState = it ?: return@Observer
//
//            // disable login button unless both username / password is valid
//            binding.btnLogin.isEnabled = loginState.isDataValid
//
//            if (loginState.usernameError != null) {
//                binding.username.error = getString(loginState.usernameError)
//            }
//            if (loginState.passwordError != null) {
//                binding.password.error = getString(loginState.passwordError)
//            }
//        })

//        loginViewModel.loginResult.observe(this@LoginActivity, Observer {
//            val loginResult = it ?: return@Observer
//
//            loading.visibility = View.GONE
//            if (loginResult.error != null) {
//                showLoginFailed(loginResult.error)
//            }
//            if (loginResult.success != null) {
//                updateUiWithUser(loginResult.success)
//            }
//            setResult(Activity.RESULT_OK)
//
//            //Complete and destroy login activity once successful
//            finish()
//        })

//        username.afterTextChanged {
//            loginViewModel.loginDataChanged(
//                username.text.toString(),
//                password.text.toString()
//            )
//        }
//
//        password.apply {
//            afterTextChanged {
//                loginViewModel.loginDataChanged(
//                    username.text.toString(),
//                    password.text.toString()
//                )
//            }
//
//            setOnEditorActionListener { _, actionId, _ ->
//                when (actionId) {
//                    EditorInfo.IME_ACTION_DONE ->
//                        loginViewModel.login(
//                            username.text.toString(),
//                            password.text.toString()
//                        )
//                }
//                false
//            }
//
//            login.setOnClickListener {
//                loading.visibility = View.VISIBLE
//                loginViewModel.login(username.text.toString(), password.text.toString())
//            }
//        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}